#' @name lib_df-class
#' 
#' @title Class containing library entries
#' 
#' @description 
#' An S3 class for library entries.
#' 
#' @exportClass lib_df
#' 
setOldClass(c("lib_df", "data.frame"))
