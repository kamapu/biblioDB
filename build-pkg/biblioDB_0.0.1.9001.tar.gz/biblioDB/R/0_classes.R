#' @name comp_df2-class
#' 
#' @title Comparison between two reference databases
#' 
#' @description 
#' Extension of class [comp_df-class] applied to comparisons of multiple data
#' frames.
#' 
#' @exportClass comp_df2
#' 
setOldClass(c("comp_df2", "list"))
